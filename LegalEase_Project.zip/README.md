# LegalEase – AI-Powered Legal Document Generator

LegalEase is a FastAPI + Streamlit project for generating editable draft legal documents with Google Gemini and exporting them as TXT, DOCX, or PDF.

## Project structure

```text
LegalEase/
├── main.py
├── routes.py
├── app.py
├── requirements.txt
├── .env.example
├── ai_core/
│   ├── __init__.py
│   └── gemini_generator.py
└── utils/
    ├── __init__.py
    └── formatters.py
```

## Setup

1. Install Python 3.10+.
2. Create and activate a virtual environment.
3. Install dependencies:

```bash
pip install -r requirements.txt
```

4. Copy `.env.example` to `.env`.
5. Add your Gemini API key to `.env`.

## Run the backend

```bash
uvicorn main:app --reload
```

## Run the frontend

Open another terminal:

```bash
streamlit run app.py
```

The Streamlit interface lets the user enter document type, parties, terms and effective date, generate a draft, edit it, preview it and download TXT/DOCX/PDF versions.

## Important

This project generates draft legal content for informational purposes. It is not a substitute for advice from a qualified legal professional.
