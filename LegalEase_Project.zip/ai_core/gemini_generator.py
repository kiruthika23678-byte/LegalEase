import os
from dotenv import load_dotenv

load_dotenv()

class GeminiDocumentGenerator:
    def __init__(self):
        self.api_key = os.getenv("GEMINI_API_KEY")
        self.model = None
        if self.api_key:
            try:
                import google.generativeai as genai
                genai.configure(api_key=self.api_key)
                self.model = genai.GenerativeModel("gemini-1.5-pro")
            except Exception:
                self.model = None

    def generate_document(self, document_type, parties, terms, dates):
        prompt = f"""
Create a professional, structured draft legal document.

Document type: {document_type}
Parties: {parties}
Terms and conditions: {terms}
Effective date: {dates}

Requirements:
- Use clear headings and numbered sections.
- Include the supplied parties, terms and date.
- Do not invent personal details that were not supplied.
- Make it clear that this is a draft and should be reviewed by a qualified legal professional.
- Return only the document text.
"""
        if self.model:
            try:
                response = self.model.generate_content(prompt)
                return response.text
            except Exception as exc:
                return f"AI generation failed: {exc}"

        return (
            f"DRAFT {document_type.upper()}\n\n"
            f"Effective Date: {dates}\n"
            f"Parties: {parties}\n\n"
            "TERMS AND CONDITIONS\n"
            f"{terms}\n\n"
            "DISCLAIMER\n"
            "This is an automatically generated draft for informational purposes "
            "and should be reviewed by a qualified legal professional before use."
        )
