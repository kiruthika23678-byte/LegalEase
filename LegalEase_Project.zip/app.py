import os
import requests
import streamlit as st
from utils.formatters import format_docx, format_pdf, format_html_preview

st.set_page_config(page_title="LegalEase", page_icon="⚖️", layout="wide")
st.title("⚖️ LegalEase")
st.caption("AI-Powered Legal Document Generator")

backend_url = os.getenv("BACKEND_URL", "http://127.0.0.1:8000")

document_type = st.text_input("Document Type", "Employment Contract")
parties = st.text_area("Parties Involved", "Employer, Employee")
terms = st.text_area(
    "Terms & Conditions",
    "Role and responsibilities; Compensation; Confidentiality; Termination notice"
)
dates = st.text_input("Effective Date", "September 25, 2026")

if "document" not in st.session_state:
    st.session_state.document = ""

if st.button("Generate Document", type="primary"):
    try:
        response = requests.post(
            f"{backend_url}/generate",
            json={
                "document_type": document_type,
                "parties": parties,
                "terms": terms,
                "dates": dates
            },
            timeout=120
        )
        response.raise_for_status()
        st.session_state.document = response.json()["document"]
    except Exception as e:
        st.error(f"Could not connect to the backend: {e}")

if st.session_state.document:
    st.subheader("Document Preview")
    st.markdown(format_html_preview(st.session_state.document), unsafe_allow_html=True)

    edited = st.text_area(
        "Click to Edit Document",
        st.session_state.document,
        height=500
    )
    st.session_state.document = edited

    c1, c2, c3 = st.columns(3)
    with c1:
        st.download_button("Download TXT", edited, "legalease_document.txt", "text/plain")
    with c2:
        st.download_button(
            "Download DOCX",
            format_docx(edited, document_type),
            "legalease_document.docx",
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
        )
    with c3:
        st.download_button(
            "Download PDF",
            format_pdf(edited, document_type),
            "legalease_document.pdf",
            "application/pdf"
        )
