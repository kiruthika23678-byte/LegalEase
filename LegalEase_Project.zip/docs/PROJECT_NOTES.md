# LegalEase Project Notes

The project follows the supplied project specification:

- Frontend: Streamlit
- Backend: FastAPI
- AI integration: Gemini
- Main API endpoint: POST /generate
- Inputs: document_type, parties, terms, dates
- Outputs: TXT, DOCX, PDF
- Editable preview: Streamlit text area
- Local deployment: Uvicorn + Streamlit

Example document types:
- Agreement
- Contract
- NDA
- Lease Agreement
- Employment Offer Letter
